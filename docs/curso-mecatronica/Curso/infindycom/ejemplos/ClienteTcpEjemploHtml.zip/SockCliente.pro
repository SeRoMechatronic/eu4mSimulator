TEMPLATE = app
CONFIG += console
TARGET = SockCliente

SOURCES += \
    sock_cliente.c

LIBS += -lws2_32
