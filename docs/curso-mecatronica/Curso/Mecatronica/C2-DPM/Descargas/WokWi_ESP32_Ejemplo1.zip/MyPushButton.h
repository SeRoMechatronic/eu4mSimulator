 #include <stdint.h>
 
class MyPushButton {
  public:
    typedef enum { BUTTON_NOT_PRESSED,BUTTON_JUST_DEPRESSED,
                   BUTTON_JUST_PRESSED,BUTTON_PRESSED } stateEnum;
  private:
    int pin;
    bool value[2]={false,false};
    bool direct;
    uint32_t lastPress=0,lastDepress=0;
    stateEnum state;
  public:
    MyPushButton(int i_pin,bool i_activeIs5V=false);
    void Run1Step();
    stateEnum GetState() const { return state; }
};