#include "MyToggleStatePushButton.h"

MyToggleStatePushButton::MyToggleStatePushButton(int i_pin,bool i_activeIs5V,toggleStateEnum i_state) : MyPushButton(i_pin,i_activeIs5V)
{
  state=i_state;
}
#include <stdio.h>

void MyToggleStatePushButton::Run1Step()
{
  MyPushButton::Run1Step();
  if (MyPushButton::GetState()==MyPushButton::BUTTON_JUST_DEPRESSED) {
    state=(state==STATE_INACTIVE) ? STATE_ACTIVE : STATE_INACTIVE;
  }
}