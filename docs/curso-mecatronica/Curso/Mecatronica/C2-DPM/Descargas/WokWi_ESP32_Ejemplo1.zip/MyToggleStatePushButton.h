#include "MyPushButton.h"

class MyToggleStatePushButton : public MyPushButton
{
  public:
    typedef enum { STATE_INACTIVE=0,STATE_ACTIVE} toggleStateEnum;
  private:
    toggleStateEnum state;
  public:
    MyToggleStatePushButton(int i_pin,bool i_activeIs5V=false,toggleStateEnum i_state=STATE_INACTIVE);
    void Run1Step();
    toggleStateEnum GetState() const { return state; }

} ;