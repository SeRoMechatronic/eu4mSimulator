#include <Arduino.h>
#include "MyPushButton.h"

MyPushButton::MyPushButton(int i_pin,bool i_activeIs5V)
{
    pin=i_pin;
    pinMode(pin,INPUT_PULLUP);
    direct=i_activeIs5V;
    value[0]=direct ? digitalRead(pin) : ! digitalRead(pin);
    Run1Step();
}


void MyPushButton::Run1Step()
{
    value[1]=value[0];
    value[0]=direct ? digitalRead(pin) : ! digitalRead(pin);
    if (!value[0] && !value[1])
      state=BUTTON_NOT_PRESSED;
    else if (value[0] && value[1])
      state=BUTTON_PRESSED;
    else if (value[0] && !value[1]) {
      lastPress=micros();
      state=BUTTON_JUST_PRESSED;
    }
    else {
      state=BUTTON_JUST_DEPRESSED;
      lastDepress=micros();
    }

}

