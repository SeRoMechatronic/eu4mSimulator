#define PIN_RED_LED 39
#define PIN_BUTTON  18

#include "MyToggleStatePushButton.h"

int _value=0;

MyToggleStatePushButton btn1(PIN_BUTTON);

void setup() {
  // put your setup code here, to run once:
  pinMode(PIN_RED_LED,OUTPUT);
  Serial.begin(115200);
  Serial.println("Hello, ESP32-S3!");
}

void loop() {
  btn1.Run1Step();
  if (btn1.GetState()==MyToggleStatePushButton::STATE_ACTIVE) {
      _value= !_value;
      digitalWrite(PIN_RED_LED,_value);
      delay(500); 
  }
  else  {
      _value=0;
      digitalWrite(PIN_RED_LED,_value);
  }
}
