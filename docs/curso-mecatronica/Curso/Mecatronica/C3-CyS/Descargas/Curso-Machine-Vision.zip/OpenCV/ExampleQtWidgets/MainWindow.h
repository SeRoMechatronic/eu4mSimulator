#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <opencv2/opencv.hpp>
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    cv::Mat imgOrigRGB,imgResultGray;
    cv::VideoCapture cap;

    void ShowImage(const cv::Mat& img,QLabel* dest);
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_qLoad_pushButton_clicked();
    void on_qProcess_pushButton_clicked();
    void on_qCap_pushButton_clicked(bool checked);
    void on_qDilateSize_spinBox_valueChanged(int arg1);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
