QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    main.cpp \
    MainWindow.cpp

HEADERS += \
    MainWindow.h

FORMS += \
    MainWindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

OPENCV_INSTALL_PATH = D:/Instalaciones/opencv   # Modificar según punto de instalación
INCLUDEPATH += $${OPENCV_INSTALL_PATH}/build/include
LIBS += -L$${OPENCV_INSTALL_PATH}/build-4.8.0/bin -lopencv_core480  -lopencv_imgcodecs480 -lopencv_imgproc480 -lopencv_video480 -lopencv_videoio480
