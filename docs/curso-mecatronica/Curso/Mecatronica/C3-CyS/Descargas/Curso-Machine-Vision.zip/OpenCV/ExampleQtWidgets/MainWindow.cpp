#include "MainWindow.h"
#include "ui_MainWindow.h"

#include <QFileDialog>


MainWindow::MainWindow(QWidget *parent)     : QMainWindow(parent), cap(0), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::ShowImage(const cv::Mat &img, QLabel *dest)
{
    QImage::Format format;
    if (img.depth()==CV_8U ) {
        if (img.channels()==1)
            format=QImage::Format_Grayscale8;
        else if (img.channels()==3)
            format=QImage::Format_BGR888;
    }
    else {
        return;
    }

    QImage qImg(img.data,img.cols,img.rows,img.step,format);

    dest->setPixmap(QPixmap::fromImage(qImg));
    dest->setScaledContents(true);
}


void MainWindow::on_qLoad_pushButton_clicked()
{
    QString fileName=QFileDialog::getOpenFileName(this,"Seleccione imagen",
                                                  "","Images (*.png *.jpg);;All files (*.*)");
    if (! fileName.isEmpty())     {
        imgOrigRGB=cv::imread(fileName.toLatin1().constData());
        ShowImage(imgOrigRGB,ui->qOrigImg_label);
    }
}

void MainWindow::on_qProcess_pushButton_clicked()
{
    cv::Mat gray;
    cv::cvtColor(imgOrigRGB,gray,cv::COLOR_RGB2GRAY);
    cv::Canny(gray,imgResultGray,255,255/3);
    on_qDilateSize_spinBox_valueChanged(-1);
}


void MainWindow::on_qCap_pushButton_clicked(bool checked)
{
    if (checked && cap.grab() )
    {
        cap.read(imgOrigRGB);
        ShowImage(imgOrigRGB,ui->qOrigImg_label);
    }
}


void MainWindow::on_qDilateSize_spinBox_valueChanged(int arg1)
{
    cv::Mat cannyDilated;
    if (arg1<0)
        arg1=ui->qDilateSize_spinBox->value();
    cv::dilate(imgResultGray,cannyDilated,cv::Mat::ones(arg1,arg1,CV_8UC1));
    ShowImage(cannyDilated,ui->qResultImg_label);

}

